
window.addEventListener("load" , registerEvents);

function registerEvents(){
    document.querySelector('#menubutton').addEventListener("click", showMobileMenu);
    document.querySelector('#crossbutton').addEventListener("click", hideMobileMenu);
}



function showMobileMenu(){
    document.querySelector("#mobilemenuitem").style.display = "block";
    document.querySelector("#menubutton").style.display = "none";
    document.querySelector("#crossbutton").style.display = "block";    
}

function hideMobileMenu(){
    document.querySelector("#mobilemenuitem").style.display = "none";
    document.querySelector("#menubutton").style.display = "block";
    document.querySelector("#crossbutton").style.display = "none";    
}